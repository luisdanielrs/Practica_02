#include <iostream>
#include<Gato.h>
using namespace std;

int main()
{
     Gato Pelusa(5,3.5);
    Pelusa.Maullar();

    cout<<"Pelusa es un gato que tiene: "<<Pelusa.ObtenerEdad()<< " anios de edad";
    cout<<" y peso de: "<<Pelusa.ObtenerPeso()<<" kilos"<<endl;

    Pelusa.Maullar();

    Pelusa.AsignarEdad(7);
    Pelusa.AsignarPeso(8.6);
    cout<<"Ahora Pelusa tiene: "<<Pelusa.ObtenerEdad()<<" anios de edad";
    cout<<" y Pelusa por comer mucho y pesa: "<<Pelusa.ObtenerPeso()<<" kilos"<<endl;

    return 0;
}

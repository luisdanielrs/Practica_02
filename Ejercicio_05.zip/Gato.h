#ifndef GATO_H
#define GATO_H


class Gato{
    public:
        Gato(int edadInicial, float pesoInicial);
        ~Gato();

        void AsignarEdad(int edad);
        void AsignarPeso(float peso);
        int ObtenerEdad() const;
        float ObtenerPeso() const;

        void Maullar();

    private:
        int suEdad;
        float suPeso;
};

#endif // GATO_H

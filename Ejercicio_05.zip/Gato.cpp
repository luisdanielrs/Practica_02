#include<iostream>
#include "Gato.h"
using namespace std;


Gato::Gato(int edadInicial, float pesoInicial){
        suEdad = edadInicial;
        suPeso = pesoInicial;
        cout<<"Se ha creado un objeto Gato de edad:  "<<edadInicial<<" y de peso: "<<pesoInicial<<endl;
    }

    Gato::~Gato(){
        cout<<"El objeto Gato se destruira en 3,2,1... ya fue..."<<endl;
    }

    // ObtenerEdad, metodo de acceso publico
    // regresa el valor de su miembro suEdad

    int Gato::ObtenerEdad() const{
        return suEdad;
    }
    float Gato::ObtenerPeso() const{
        return suPeso;
    }
    // Definicion de AsignarEdad, metodo de acceso publico

    void Gato::AsignarEdad(int edad){
        //aginar a la variable miembro su Edad el valor pasado por el parametro edad
        suEdad = edad;
    }
    void Gato::AsignarPeso(float peso){
        //aginar a la variable miembro su Edad el valor pasado por el parametro edad
        suPeso = peso;
    }

    // definicion del metodo maullar
    void Gato::Maullar(){
        cout<<"Miauuu"<<endl;
    }

